int pantalla;
PImage logo;
PImage fondo;
PImage cartel;
PImage jojo;
PImage dio;
PImage jojopapa;
PImage diopapa;
PImage speedwagon;
PImage zeppeli;
PImage mascara;
PImage jovenjojo;
PImage jovendio;

void setup() {
  size(1200,650);
  
//imagenes
  logo=loadImage("logo.png");
  cartel=loadImage("cartel.png");
  jojo=loadImage("jojo.png");
  jovenjojo=loadImage("jovenjojo.png");
  dio=loadImage("dio.png");
  jovendio=loadImage("jovendio.png");
  jojopapa=loadImage("jojopapa.png");
  diopapa=loadImage("diopapa.png");
  speedwagon=loadImage("speedwagon.png");
  zeppeli=loadImage("zeppeli.png");
  mascara=loadImage("mascara.png");
  
  
  pantalla = 0;
  texto = 0;
}


void draw(){

//pantalla de inicio
  if (pantalla == 0){
//Fondo
  fondo=loadImage("inicio.jpeg");
  image(fondo,0,0,width,height);
//Logo
  image(logo,155,-7,940,250);
//Boton
  if(dist(mouseX,mouseY,599,493)<50){
   fill(255,0,0);
   stroke(135,0,0);
    if(mousePressed){
    pantalla = 1;
  }
  } else {
     fill(128,0,128);
     stroke(75,0,130);
     
  }
 ellipse(599,493,100,100);
 fill(0);
 triangle(580,467,629,495,580,520);
 fill(0,0,0,0);
  }
  
//Pantallas
 if (pantalla == 1){
  fondo=loadImage("Casa-Joestars.png");
  escenario();
 }
 if (texto == 0){
  textSize(30);
  text("Para avanzar y retroceder el texto usa las flechas derecha/izquierda del teclado :)",30,450);
 }
 if (texto == 1){
 textSize(20);
   image(jojopapa, 99, 52, 360, 342);
   text("Esta historia empieza en Inglaterra 1880, cuando el millonario George Joestar vuelca su carruaje y cae por un barranco junto con su esposa",26,440);
   text("e hijo.",26,465);
   text("Ese dia, Geroge y su familia volvian de una subasta de reliquias antiguas y debido a la lluvia, su carruaje descarrilo, cayendo por un",26,490);
   text("barranco. Los unicos supervivientes de ese accidente fueron George y su hijo Jonatan.",26,515);
   text("Debido al impacto, George perdio la conciencia. Cuando desperto, aun aturdido por lo sucedido, logro visualizar a un hombre...",26,540);
 }
 if (texto == 2){
   image(jojopapa,99,52,360,342);
   image(diopapa,740,72,360,320);
   text("Dicho hombre era Dario Brando, un estafador provinientes de los barrios mas peligrosos del pais. Dario se habia acercado al accidente",26,440);
   text("en busca de objetos de valor y George, al ver que Dario le estaba tomando de la mano, confundio su intento por robar anillos con un", 26, 465);
   text("rescate, quedando, segun el, en deuda con el Sr.Brando.",26,490);
   text("Deuda que se cobraria muchos años despues.",26,515);
 }
 if (texto == 3){
   fondo=loadImage("JoestarMansion.png");
   escenario();
   image(jovenjojo,85,40,380,362);
   image(mascara,740,72,310,270);
   text("Ocho años pasaron desde el accidente y el joven Jonatan Joestar, mejor conocido como Jojo, ya tiene 12 años. Pese al dolor, los Joestar",26,440);
   text("lograron seguir adelante y Jojo habia crecido feliz, desarrondo un corazon tan honorable y compasibo como el de su viejo.",26,465);
   text("A esas alturas, como unico recuerdo del incidente solo quedaba una mascara de piedra, que era exibida en el hall de la mansion Joestar.",26,500);
   text("Desde el accidente, los Joestar habian vivido en paz, pero todavia quedaba una supuesta deuda por cobrar...",26,525);
 }
 if (texto == 4){
   fondo=loadImage("ogrestreet.jpeg");
   escenario();
   text("Nos tramportamos un momento a los barrios bajos de London, especificamente a Ogre Street.",26,440);
   
 } 
 
 //Coord
  fill (0,250,0);
  textSize (20);
  text(mouseX + " - " + mouseY, mouseX, mouseY);
}
