//Avanzar y retroceder

int texto;
void keyPressed(){
 if (pantalla >= 1){
  if (keyCode == LEFT){
    texto = texto - 1;
  }
  if (keyCode == RIGHT){
    texto = texto + 1;
  }
  if (texto < 0){
  texto = 0;
  }
 }
}

//Escenas

void escenario(){
  image(fondo,0,0,width,height);
  fill(0,0,255,200);
  noStroke();
  rect(7,280,626,195,20);
  fill(0);
}
